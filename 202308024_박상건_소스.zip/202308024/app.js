const express = require('express');
const path = require('path');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.get('/', (req, res) => {
    res.render('index', {
        name: '박상건',
        hakbun: 202308024,
        age: 24,
        hakgwa: '정보통신공학과',
        food: '생새우',
    });
});

// 서버 실행
app.listen(3000, () => {
    console.log(`서버 실행: http://localhost:3000`);
});
